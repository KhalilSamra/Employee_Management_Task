﻿using Employee_Management_Task.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace Employee_Management_Task.Data
{
	public class AppDBContext:DbContext
	{
		public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
		{ }


		//define 
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			//define primary keys
			modelBuilder.Entity<EmployeeJob>().HasKey(ej => new
			{
				ej.EmployeeId,
				ej.JobID,
				//primary keys

			});

			//define EmployeeJob to be the joining table(model)


			//Employee table
			modelBuilder.Entity<EmployeeJob>().HasOne(ej => ej.Employee)
				.WithMany(e => e.EmployeeJobs).HasForeignKey(ej => ej.EmployeeId);

			//Job table
			modelBuilder.Entity<EmployeeJob>().HasOne(ej => ej.Job)
				.WithMany(am => am.EmployeeJobs).HasForeignKey(ej => ej.JobID);



			base.OnModelCreating(modelBuilder);
		}



		public DbSet<Employee> employees { get; set; }

		public DbSet<Job> jobs { get; set; }
		public DbSet<EmployeeJob> employeejobs { get; set; }

	}
}
