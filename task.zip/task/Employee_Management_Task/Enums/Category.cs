﻿namespace Employee_Management_Task.Enums
{
	public enum Category
	{
		First = 1,
		Second,
		Third
	}
}
