﻿namespace Employee_Management_Task.Enums
{
	public enum Governorate
	{
		Akkar=1, 
		Beirut,
		Beqaa, 
		Nabatieh
	}

}
