﻿using Employee_Management_Task.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Employee_Management_Task.Models
{
	[Table("tblEmployees")]
	public class Employee
	{
		[Key]
		public int Id { get; set; }

		[Required, MaxLength(50)]
		public string Name { get; set; }

		[DataType(DataType.Date)]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
		public DateTime BirthDate { get; set; }

		[Phone]
		public string Phone { get; set; }


		[Required ]
		public DateTime EmploymentDate { get; set; }

		public byte[]? PersonalPhoto { get; set; }

		public Governorate Governorate { get; set; }

        [Display(Name = "On Probation")]
        public bool? isProbation { get; set; }

        [Display(Name = "Is Deleted")]
        public bool? isDeleted { get; set; }


		//RelationShip
	
		public List<EmployeeJob>? EmployeeJobs { get; set; }




	}
}

	

