﻿namespace Employee_Management_Task.Models
{
	public class EmployeeJob
	{
		public int JobID { get; set; }
		public int EmployeeId { get; set; }

		public Employee? Employee { get; set; }
		public Job? Job { get; set; }

        public bool isActive { get; set; }
	}
}
