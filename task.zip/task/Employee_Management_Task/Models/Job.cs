﻿using Employee_Management_Task.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Employee_Management_Task.Models
{
	
	[Table("tblJobs")]
	public class Job
	{

		[Key]
		public int JobId { get; set; }

		[MaxLength(50)]
		public string Name { get; set; }


		public Category Category { get; set; }

        //RelationShip
        [NotMapped]
        public List<EmployeeJob>? EmployeeJobs { get; set; }


	}
}
