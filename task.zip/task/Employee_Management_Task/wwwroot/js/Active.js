﻿function getActiveEmployees() {
    const isActive = true; 
    const employeeName = document.getElementById('employeeNameFilter').value;
    const jobName = document.getElementById('jobNameFilter').value;

    alert(1);

    fetch(`/Employee/GetActiveEmployees`)
        .then(response => response.json())
        .then(data => {
            alert(2);
            displayData(data);
        })
        .catch(error => console.error('Error:', error));
}
