﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Employee_Management_Task.Migrations
{
    public partial class changes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
