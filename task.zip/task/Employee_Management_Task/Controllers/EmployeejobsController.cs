﻿using Employee_Management_Task.Data;
using Employee_Management_Task.Models;
using Microsoft.AspNetCore.Mvc;

namespace Employee_Management_Task.Controllers
{
    public class EmployeejobsController : Controller
    {

        private readonly AppDBContext _empJob;

        public EmployeejobsController(AppDBContext empJob)
        {
            _empJob = empJob;
        }


		public IActionResult GetEmployeeJob()
		{
			List<EmployeeJob> list=_empJob.employeejobs.ToList();
			return View(list);
		}



        [HttpGet]
		public IActionResult AddEmployeeJob()
		{
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult AddEmployeeJob(EmployeeJob empJob)
		{
			
				


			if (ModelState.IsValid)
			{
				_empJob.employeejobs.Add(empJob);
				_empJob.SaveChanges();

				return RedirectToAction("GetEmployeeJob");
			}
			return View(empJob);




		}

    }
}
