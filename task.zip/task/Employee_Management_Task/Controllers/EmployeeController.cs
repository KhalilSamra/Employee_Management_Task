﻿using Employee_Management_Task.Data;
using Employee_Management_Task.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Employee_Management_Task.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly AppDBContext _emp;

        public EmployeeController(AppDBContext emp)
        {
            _emp = emp;
        }


        public async Task<IActionResult> GetEmployees()
        {
            List<Employee> list = await _emp.employees.ToListAsync();
            return View(list);
        }



        [HttpGet]
        public IActionResult AddEmployee()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddEmployee(Employee emp)
        {


            if (emp.Name == emp.Phone)
            {
                ModelState.AddModelError("name", " the name cannot be  same as the Phone");
            }
            if (ModelState.IsValid)
            {
                _emp.employees.Add(emp);
                _emp.SaveChanges();
              
                return RedirectToAction("GetEmployees");
            }
            return View(emp);
        }




        //[HttpPost]
        //public async Task<IActionResult> AddEmployee(Employee emp)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _emp.Add(emp);
        //            await _emp.SaveChangesAsync();
        //            return RedirectToAction("GetEmployees");

        //        }
        //        catch (Exception ex) {
        //            ModelState.AddModelError(string.Empty, $" Something went wrong{ex.Message}");
        //        }
        //    }
        //    ModelState.AddModelError(string.Empty, $" Something went wrong!");


        //    return View(emp);

        //}

        [HttpGet]
        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var empFromDb = _emp.employees.Find(id);
            //var first = _db.details.FirstOrDefault(u => u.Id == id);
            if (empFromDb == null)
            {
                return NotFound();
            }
            return View(empFromDb);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Employee emp)
        {

            if (emp.Name == emp.Phone)
            {
                ModelState.AddModelError("name", " the name cannot be  same as the Phone");
            }
            if (ModelState.IsValid)
            {
                _emp.employees.Update(emp);
                _emp.SaveChanges();
               
                return RedirectToAction("GetEmployees");
            }
            return View(emp);
        }


        public IActionResult GetEmployeesByID(int jobId)
        {
      
            var employees = _emp.employeejobs
                .Where(ej => ej.JobID == jobId)  
                .Select(ej => ej.Employee)        
                .ToList();

            return Json(employees);
        }

        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var empFromDb = _emp.employees.Find(id);
            if (empFromDb == null)
            {
                return NotFound();
            }

            return View(empFromDb);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(Employee emp)
        {
            _emp.employees.Remove(emp);
            _emp.SaveChanges();
            return RedirectToAction("GetEmployees");

        }



        public IActionResult GetActiveEmployees(bool isActive = true, string employeeName = "", string jobName = "")
        {
            var query = _emp.employeejobs.AsQueryable();

            if (isActive)
            {
                query = query.Where(ej => ej.isActive == true);
            }

            if (!string.IsNullOrEmpty(employeeName))
            {
                query = query.Where(ej => ej.Employee.Name.Contains(employeeName));
            }

            if (!string.IsNullOrEmpty(jobName))
            {
                query = query.Where(ej => ej.Job.Name.Contains(jobName));
            }

            var employees = query
                .Select(ej => ej.Employee)
                .ToList();

            return Json(employees);
        }



        public IActionResult GetActiveEmployees2()
        {

            var employees = _emp.employeejobs
                .Where(ej => ej.isActive == true)
                .Select(ej => ej.Employee)
                .ToList();

            return Json(employees);
        }



    }
}
