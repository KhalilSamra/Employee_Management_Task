﻿using Employee_Management_Task.Data;
using Employee_Management_Task.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Employee_Management_Task.Controllers
{
	public class JobController : Controller
	{
		private readonly AppDBContext _job;
        public JobController(AppDBContext job)
        {
            _job = job;
        }
        public IActionResult GetJobs()
		{
			List<Job> j=_job.jobs.ToList();	
			return View(j);
		}



		//public IActionResult GetEmployeesByJobId(int jobId)
		//{

		//    var employees = _job.employeejobs
		//        .Where(ej => ej.JobID == jobId)  
		//        .Select(ej => ej.Employee)
		//        .ToList();

		//    return Json(employees);
		//}



		[HttpGet]
		public IActionResult AddJob()
		{
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult AddJob(Job j)
		{
			// emp.EmployeeJobs = new List<EmployeeJob>();


			if (ModelState.IsValid)
			{
				_job.jobs.Add(j);
				_job.SaveChanges();

				return RedirectToAction("GetJobs");
			}
			return View(j);
		}


        [HttpGet]
        public IActionResult EditJobs(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var jobFromDb = _job.jobs.Find(id);
            if (jobFromDb == null)
            {
                return NotFound();
            }
            return View(jobFromDb);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditJobs(Job j)
        {

            if (ModelState.IsValid)
            {
                _job.jobs.Update(j);
                _job.SaveChanges();

                return RedirectToAction("GetJobs");
            }
            return View(j);
        }


        [HttpGet]
        public IActionResult DeleteJob(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var jobFromDb = _job.jobs
                .Where(x => x.JobId == id)
                .FirstOrDefault(); 
            if (jobFromDb == null)
            {
                return NotFound();
            }
            _job.jobs.Remove(jobFromDb);
            _job.SaveChanges();

            return RedirectToAction("GetJobs");

        }


    }
}
